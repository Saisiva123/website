import {
	Component,
	EventEmitter,
	Output,
	ViewEncapsulation
} from "@angular/core";
import { DataManagerService } from "../../../../shared/services/data.svc";
@Component({
	selector: "ec-cb-inputText",
	templateUrl: "./inputText.component.html",
	encapsulation: ViewEncapsulation.None,
	styleUrls: ["./inputText.component.scss"]
})
export class EcCbInputText {
	@Output() emitOptionOnWindow = new EventEmitter<boolean>();
	@Output() emitGotoID = new EventEmitter<string>();
	keyword: string = "title";
	question: string = "";
	questionList: string = "";
	answers: object;
	isLoading: boolean = false;
	inputValue:string="";
	voiceSearchActive = false;
	constructor(private dataManagerService: DataManagerService) {}


	onSendClick(data) {
		console.log(this.inputValue);
		this.onChangeSearch(this.inputValue);
	}
	selectEvent(selectedQuestion) {
		// this.dataManagerService.getAns(this.question).subscribe((data: any) => {
		// 	this.answers = data;
		// 	console.log("getAns() ", this.answers);
		// });
		let q = selectedQuestion.title;
		let a = selectedQuestion.text;
		a =
			a +
			`<br/><br/>The content is a little too large to read here hence, please <a href="${
				selectedQuestion.linkUrl
			}" target="_blank">read it here...</a>`;
		let opt: any = {
			source: "UserResponse",
			display: q
		};
		this.emitOptionOnWindow.emit(opt);
		opt = {
			source: "FAQ",
			text: a
		};
		this.emitOptionOnWindow.emit(opt);
		this.emitGotoID.emit("F2");
	}
	onChangeSearch(searchQuestion) {
		this.isLoading = true;
		this.dataManagerService
			.getAns(searchQuestion)
			.subscribe((data: any) => {
				this.isLoading = false;
				this.questionList = data;
				// console.log("getAns() ", this.answers);
			});
	}
	onFocused() {
		// this.dataManagerService.getAns(this.question).subscribe((data: any) => {
		// 	this.answers = data;
		// 	console.log("getAns() ", this.answers);
		// });
	}

	/*getList() {
		this.dataManagerService.getAns(this.question).subscribe((data: any) => {
			this.answers = data;
			let q = this.answers[0].title;
			let a = this.answers[0].text;
			a =
				a +
				`<br/><br/>The content is a little too large to read here hence, please <a href="${
					this.answers[0].linkUrl
				}" target="_blank">read it here...</a>`;
			let opt: any = {
				source: "UserResponse",
				display: q
			};
			this.emitOptionOnWindow.emit(opt);
			opt = {
				source: "FAQ",
				text: a
			};
			this.emitOptionOnWindow.emit(opt);
			this.emitGotoID.emit("F2");
			// this.answers.searchResults[0].title
			// this.answers.searchResults[0].text
			console.log("getAns() ", this.answers);
		});
	}*/
}
