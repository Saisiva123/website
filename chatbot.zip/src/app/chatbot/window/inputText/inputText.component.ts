import { Component, Output, EventEmitter } from "@angular/core";
import { DataManagerService } from "../../../shared/services/data.svc";
// import { Options } from "../messages/message.model";

@Component({
	selector: "ec-cb-inputText",
	templateUrl: "./inputText.component.html",
	styleUrls: ["./inputText.component.scss"]
})
export class EcCbInputText {
	@Output() emitOptionOnWindow = new EventEmitter<boolean>();
	@Output() emitGotoID = new EventEmitter<string>();
	question: string = "";
	answers: any;

	constructor(private dataManagerService: DataManagerService) {}

	onSendClick() {
		this.dataManagerService.getAns(this.question).subscribe((data: any) => {
			this.answers = data;
			let q = this.answers[0].title;
			let a = this.answers[0].text;
			a =
				a +
				`<br/><br/>The content is a little too large to read here hence, please <a href="${
					this.answers[0].linkUrl
				}" target="_blank">read it here...</a>`;
			let opt: any = {
				source: "UserResponse",
				display: q
			};
			this.emitOptionOnWindow.emit(opt);
			opt = {
				source: "FAQ",
				text: a
			};
			this.emitOptionOnWindow.emit(opt);
			this.emitGotoID.emit("F2");
			// this.answers.searchResults[0].title
			// this.answers.searchResults[0].text
			console.log("getAns() ", this.answers);
		});
	}
}
