import { Component, Input, OnInit } from "@angular/core";

@Component({
  selector: "ec-cb-image",
  templateUrl: "./image.component.html",
  styleUrls: ["./image.component.scss"]
})
export class EcCbImage implements OnInit {
  @Input() image: Array<"">;
  public imageData: Array<"">;

  ngOnInit() {
    this.imageData = this.image;
  }
}
