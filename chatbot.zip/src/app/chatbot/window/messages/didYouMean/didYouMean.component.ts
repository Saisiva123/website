import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { DataManagerService } from "../../../../shared/services/data.svc";
// import { Options } from "../message.model";

@Component({
  selector: "ec-cb-did-you-mean",
  templateUrl: "./didYouMean.component.html",
  styleUrls: ["./didYouMean.component.scss"]
})
export class EcCbDidYouMean implements OnInit {
  // @Input() options: Array<"">;
  // @Output() emitOptionOnMsg = new EventEmitter<{
  //   display: String;
  //   next: String;
  // }>();
  // public optionsData: Array<"">;
  @Input() didYouMeanList: Array<any>;
  @Output() emitOptionOnMsg = new EventEmitter<{
    source: String;
    display: String;
    text: [String]|undefined;
    next: String|any;
  }>();
  @Output() emitGotoID = new EventEmitter<string>();
  // didYouMeanList:[];

  constructor(private dataManagerService: DataManagerService) {}

  ngOnInit() {
    // this.optionsData = this.options;
    // this.dataManagerService.didYouMeanList.subscribe(data =>{
    //   this.didYouMeanList = data;
    // });
  }
  onClickDidYouMean(e) {
    console.log("onClickDidYouMean", e);
    this.emitOptionOnMsg.emit({
        source: "UserResponse",
        display: e.title,
        text:undefined,
        next:undefined
    });
      let a = e.text;
      a =
        a +
        `<br/><br/>The content is a little too large to read here hence, please <a href="${
          e.linkUrl
        }" target="_blank">read it here...</a>`;
    this.emitOptionOnMsg.emit({
        source: "FAQ",
        display: a,
        text:undefined,
        next:undefined
    });
    this.emitGotoID.emit("F2");
  }
  onClickNoneOfThese(e) {
    console.log("onClickNoneOfThese", e);
  }


  // on select option pass the selected object to message
  // onSelectOption(opt: Options) {
  //   opt.source = "UserResponse";
  //   this.emitOptionOnMsg.emit(opt);
  // }
}
