import { Component, Input } from "@angular/core";

@Component({
  selector: "ec-cb-link",
  templateUrl: "./link.component.html",
  styleUrls: ["./link.component.scss"]
})
export class EcCbLink {
  @Input() link: Array<"">;
  public linkData: Array<"">;

  ngOnInit() {
    this.linkData = this.link;
  }
}
