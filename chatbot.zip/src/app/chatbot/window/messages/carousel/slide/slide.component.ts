import { Component, Input, EventEmitter, Output, OnInit } from "@angular/core";

@Component({
  selector: "ec-cb-carousel-slide",
  templateUrl: "./slide.component.html",
  styleUrls: ["./slide.component.scss"]
})
export class EcCbCarouselSlide implements OnInit {
  @Input() carousel: Array<any> = [];
  slideData: Array<any> = [];
  showDetailModal: boolean;
  @Output() emitMSlideStatus = new EventEmitter<any>();

  ngOnInit() {
    this.slideData = this.carousel;
  }

  // emit the details modal visible status to window 
  productDetails(data) {
    this.emitMSlideStatus.emit( { display: data, type: 'details' });
  }
  // emit the see price modal visible status to window
  productPrice(data) {
    this.emitMSlideStatus.emit( { display: data, type: 'price' });
  }
}
