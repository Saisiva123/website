import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  AfterViewInit
} from '@angular/core';
import { ConfigServcie } from 'src/app/shared/services/config.svc';

// creating model for option object
class OptionObj {
  public source: string;
  public text: Array<string>;

  constructor(source: string, text: Array<string>) {
    this.source = source;
    this.text = text;
  }
}

@Component({
  selector: "ec-cb-messages",
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class EcCbMessages implements OnInit, AfterViewInit {
  @Input() message: any;
  @Input() carousel: Array<any>;
  text: any;
  options: Array<[]>;
  image: Array<[]>;
  carouselData: Array<[]>;
  linkData: Array<[]>;
  isLastOption = true;
  public isLast = false;
  showButtons = true;
  optionObj: OptionObj;
  content: any = {};
  @Output() emitOptionOnWindow = new EventEmitter<boolean>();
  @Output() emitMessageInited = new EventEmitter<boolean>();
  @Output() emitMWindowStatus = new EventEmitter<boolean>();
  @Output() emitGotoID = new EventEmitter<string>();
  constructor(private configServcie: ConfigServcie) {
  }

  ngOnInit() {
    this.getMesssageObj();
    this.content = this.configServcie.staticContent;
  }
  ngAfterViewInit() {
    this.emitMessageInited.emit();
  }

  // get the message object which comes for window component and filter the object into category
  getMesssageObj() {    
    if (this.message){
      if (this.message.text) {
        this.optionObj = new OptionObj(this.message.source, this.message.text);
        this.text = this.optionObj;
      }
      if (this.message.options) {
        this.options = this.message.options;
      }
      if (this.message.image) {
        this.image = this.message.image;
      }
      if (this.message.carousel) {
        this.carouselData = this.message.carousel;
      }
      if (this.message.link) {
        this.linkData = this.message.link;
      }
    }

  }

  // function to pass the option data to window and hide the old option array of data
  onEmitOptionOnMsg(opt) {
    this.showButtons = false;
    this.emitOptionOnWindow.emit(opt);
  }

  // function is used to pass the carousel visible status to window
  onEmitMCarouselStatus(eve) {
    this.emitMWindowStatus.emit(eve);
  }

  onEmitGotoID(e){
    this.emitGotoID.emit(e);
  }

  // function is used to check the option is object is last or not and set the state of varible
  checkIsLastOpt(ev) {
    if (ev == 'forOpt') {
      this.isLastOption = false;
    } else {
      this.isLast = true;
    }
  }
}
