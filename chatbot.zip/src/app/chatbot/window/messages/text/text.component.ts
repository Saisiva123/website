import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: "ec-cb-text",
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss']
})
export class EcCbText implements OnInit {
  public msgFromReciver = true;
  @Input() texts: Array<any>;
  public textData: any;
  speakerState = 'mute';
  ngOnInit() {
    this.textData = this.texts;
  }
}
