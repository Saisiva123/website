import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient, HttpParams } from "@angular/common/http";
import { catchError, tap, map } from "rxjs/operators";

// FOR USE AFTER DATA CONNECTIVITY
// const apiUrl = "http://localhost:3001/message/";
const faqUrl = "http://localhost:3001/getFAQ"; //"https://knowledge.autodesk.com/autodesk-faceted-search/search";
//?isLearn= 0&rows= 25&search= I am unable to copy and paste in autocad&sort= score&start= 0";
const apiUrl = '../assets/data/chat.json';

@Injectable({
  providedIn: "root"
})
export class DataManagerService {
  private carousel = [
    {
      title: "Acer Aspire GX 281-UR13",
      subtitle: "AMD Ryzen 7 1700X - 1TB HDD - 16GB RAM",
      url: "https://www.amd.com/en/shop/us/Desktops",
      thumbnail:
        "https://pricing27.eclerx.com/desktop/ecx-New-US-9SIAA0S92G2760_l.jpg",
      price: "$ 875.00",
      retail_logo:
        "https://wpdev.eclerx.com:4502/chatbot/assets/retailer/Newegg.com-US.jpg",
      retail_link:
        "http://www.tkqlhce.com/click-5257136-10446076?sid=ShopAMD&url=https://www.newegg.com/acer-aspire-gx-281-ur13-gaming-entertainment/p/1VK-0017-00AN6",
      details: {
        mfg: "Acer",
        int_memo: "16GB",
        hdd: "1TB",
        os: "Windows 10 Home",
        cpu_m: "AMD Ryzen 7 1700X",
        cpu_cs: 3400,
        cpu_c: 8,
        gpu_c: 8,
        core: "15 Compute Cores (4 CPU + 11 GPU)*",
        f_factor: "Tower",
        aud_type: "High-Def Audio with 5.1 Channel surround sound support",
        opt_drive: "8X DVD-Writer Double-Layer Drive (DVD-RW)",
        weight: "18.43lbs",
        n_speed: "10/100/1000"
      }
    },
    {
      title: "Lenovo ThinkCentre M725s",
      subtitle:
        "AMD Ryzen 5 PRO 2400G with Radeon Vega 11 Graphics - 1TB HDD - 16GB RAM",
      url: "https://www.amd.com/en/shop/us/Desktops",
      thumbnail:
        "https://pricing27.eclerx.com/desktop/ecx-New-US-9SIAA0S92G2760_l.jpg",
      price: "$ 749.99",
      retail_logo:
        "https://wpdev.eclerx.com:4502/chatbot/assets/retailer/Newegg.com-US.jpg",
      retail_link:
        "https://www.newegg.com/lenovo-thinkcentre-m725s-business-desktop-workstation/p/1VK-0003-0BRZ3?nm_mc=AFC-C8Junction&cm_mmc=AFC-C8Junction--_-na-_-na-_-na&cm_sp=&AID=10446076&PID=5257136&SID=ShopAMD&cjevent=fd67a0c2860911e9839b01af0a180510",
      details: {
        mfg: "Lenovo",
        int_memo: "16GB",
        hdd: "1TB",
        os: "Windows 10 Pro",
        cpu_m: "AMD Ryzen 5 PRO 2400G with Radeon Vega Graphics",
        cpu_cs: 3600,
        cpu_c: 4,
        gpu_c: 11,
        core: "15 Compute Cores (4 CPU + 11 GPU)*",
        f_factor: "Small Form Factor",
        aud_type: "High Definition Audio",
        opt_drive: "DVD±R/±RW",
        weight: "13.23lbs",
        n_speed: "10/100/1000"
      }
    },
    {
      title: "Alienware Aurora R6",
      subtitle: "Non-AMD - 1TB HDD - 8GB RAM - Radeon RX 560X",
      url: "https://www.amd.com/en/shop/us/Desktops",
      thumbnail:
        "https://pricing27.eclerx.com/desktop/ecx-New-US-9SIAA0S92G2760_l.jpg",
      price: "$ 749.99",
      retail_logo:
        "https://wpdev.eclerx.com:4502/chatbot/assets/retailer/dell-us.jpg",
      retail_link:
        "http://www.dell.com/en-us/shop/productdetails/alienware-aurora-r7-desktop/dpcwxtc01h",
      details: {
        mfg: "Alienware",
        int_memo: "8GB",
        hdd: "1TB",
        os: "Windows 10 Home",
        cpu_m: "Radeon RX 560X",
        cpu_cs: "",
        gpu_c: 11,
        core: "15 Compute Cores (4 CPU + 11 GPU)*",
        f_factor: "Tower",
        aud_type: "High Definition Audio",
        opt_drive: "DVD±R/±RW",
        weight: "13.23lbs",
        n_speed: "10/100/1000"
      }
    },
    {
      title: "Lenovo ThinkCentre M725s",
      subtitle:
        "AMD Ryzen 5 PRO 2400G with Radeon Vega 11 Graphics - 512GB HDD - 64GB RAM",
      url: "https://www.amd.com/en/shop/us/Desktops",
      thumbnail:
        "https://pricing27.eclerx.com/desktop/ecx-New-US-9SIAA0S92G2809_l.jpg",
      price: "$ 1059.99",
      retail_logo:
        "https://wpdev.eclerx.com:4502/chatbot/assets/retailer/Newegg.com-US.jpg",
      retail_link:
        "http://www.tkqlhce.com/click-5257136-10446076?sid=ShopAMD&url=https://www.newegg.com/lenovo-thinkcentre-m725s-business-desktop-workstation/p/1VK-0003-0BS13",
      details: {
        mfg: "Lenovo",
        int_memo: "16GB",
        hdd: "1TB",
        os: "Windows 10 Pro",
        cpu_m: "AMD Ryzen 5 PRO 2400G with Radeon Vega Graphics",
        cpu_cs: 3600,
        cpu_c: 4,
        gpu_c: 11,
        core: "15 Compute Cores (4 CPU + 11 GPU)*",
        f_factor: "Small Form Factor",
        aud_type: "High Definition Audio",
        opt_drive: "DVD±R/±RW",
        weight: "13.23lbs",
        n_speed: "10/100/1000"
      }
    },
    {
      title: "Lenovo ThinkCentre M725s",
      subtitle:
        "AMD Ryzen 5 PRO 2400G with Radeon Vega 11 Graphics - 1TB HDD - 64GB RAM",
      url: "https://www.amd.com/en/shop/us/Desktops",
      thumbnail:
        "https://pricing27.eclerx.com/desktop/ecx-New-US-9SIAA0S92G2794_l.jpg",
      price: "$ 1189.99",
      retail_logo:
        "https://wpdev.eclerx.com:4502/chatbot/assets/retailer/Newegg.com-US.jpg",
      retail_link:
        "http://www.tkqlhce.com/click-5257136-10446076?sid=ShopAMD&url=https://www.newegg.com/lenovo-thinkcentre-m725s-business-desktop-workstation/p/1VK-0003-0BS08",
      details: {
        mfg: "Lenovo",
        int_memo: "16GB",
        hdd: "1TB",
        os: "Windows 10 Pro",
        cpu_m: "AMD Ryzen 5 PRO 2400G with Radeon Vega Graphics",
        cpu_cs: 3600,
        cpu_c: 4,
        gpu_c: 11,
        core: "15 Compute Cores (4 CPU + 11 GPU)*",
        f_factor: "Small Form Factor",
        aud_type: "High Definition Audio",
        opt_drive: "DVD±R/±RW",
        weight: "13.23lbs",
        n_speed: "10/100/1000"
      }
    }
  ];
  private b = [
    {
      source: "Message",
      id: "G1",
      category: "Greeting",
      text: [
        "Hi there! 👋 Great to see you",
        "I’m AMDesia. I’m your personal Product Adviser for AMD. 🙂"
      ],
      image: [
        {
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture1.jpg"
        }
      ],
      link: [
        {
          title: "Title",
          subtitle: "Sub title",
          thumbnail: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture1.jpg",
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture1.jpg"
        }
      ],
      next: "P1"
    },
    {
      source: "Message",
      id: "G2",
      category: "Greeting",
      text: ["Welcome back let's start again"],
      next: "P1"
    },
    {
      source: "Message",
      id: "P1",
      category: "Profiling",
      text: ["So tell me, where are you from?"],
      options: [
        {
          text: "Brazil",
          display: "I’m from Brazil",
          value: "br",
          attr: "location",
          next: "P3_BR"
        },
        {
          text: "Canada",
          display: "I’m from Canada",
          value: "ca",
          attr: "location",
          next: "P3_CA"
        },
        {
          text: "China",
          display: "I’m from China",
          value: "cn",
          attr: "location",
          next: "P3_CN"
        },
        {
          text: "Germany",
          display: "I’m from Germany",
          value: "de",
          attr: "location",
          next: "P3_DE"
        },
        {
          text: "Spain",
          display: "I’m from Spain",
          value: "es",
          attr: "location",
          next: "P3_ES"
        },
        {
          text: "France",
          display: "I’m from France",
          value: "fr",
          attr: "location",
          next: "P3_FR"
        },
        {
          text: "Great Britain",
          display: "I’m from Great Britain",
          value: "gb",
          attr: "location",
          next: "P3_GB"
        },
        {
          text: "India",
          display: "I’m from India",
          value: "in",
          attr: "location",
          next: "P3_IN"
        },
        {
          text: "Sweden",
          display: "I’m from Sweden",
          value: "se",
          attr: "location",
          next: "P3_SE"
        },
        {
          text: "United States",
          display: "I'm from the States",
          value: "us",
          attr: "location",
          next: "P3_US"
        }
      ]
    },
    {
      source: "Message",
      id: "P3_US",
      category: "Profiling",
      text: [
        "<i>The best way to predict your future is to create it.</i>said Abraham Lincoln"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_SE",
      category: "Profiling",
      text: ["Be yourself. The world worships the original.–Ingrid Bergman"],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_IN",
      category: "Profiling",
      text: [
        "Live as if you were to die tomorrow. Learn as if you were to live forever.–Gandhiji"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_GB",
      category: "Profiling",
      text: [
        "Without stories, we wouldn’t be human beings at all.-Philip Pullman"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_FR",
      category: "Profiling",
      text: ["In a great mind everything is great.- Blaise Pascal"],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_ES",
      category: "Profiling",
      text: [
        "You only live once, but if you do it right, once is enough.-Mae West"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_DE",
      category: "Profiling",
      text: [
        "Live each day as if your life had just begun. Johann Wolfgang von Goethe, writer"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_CN",
      category: "Profiling",
      text: [
        "The journey of a thousand miles starts with a single step.” Lao Tzu"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_CA",
      category: "Profiling",
      text: ["Canada is the homeland of equality, justice and tolerance."],
      next: "P4"
    },
    {
      source: "Message",
      id: "P3_BR",
      category: "Profiling",
      text: [
        "A lot of fighters come from Brazil. We've been doing this for long, long years"
      ],
      next: "P4"
    },
    {
      source: "Message",
      id: "P4",
      category: "Profiling",
      text: [
        "<i>The best way to predict your future is to create it.</i> said Abraham Lincoln",
        "Which of our products do you wish to explore?"
      ],
      options: [
        {
          text: "Computers",
          display: "I’m looking for a computer",
          value: "Desktop",
          attr: "productType",
          next: "P4_1"
        },
        {
          text: "Components",
          display: "I’m looking for a components",
          value: "component",
          attr: "productType",
          next: "P4_2"
        }
      ]
    },
    {
      source: "Message",
      id: "P4_1",
      category: "Profiling",
      text: [
        "Did you know? 76% of customers prefer to play games on mobile devices while 62% prefer playing on PC."
      ],
      next: "P5"
    },
    {
      source: "Message",
      id: "P4_2",
      category: "Profiling",
      text: [
        "Did you know? 76% of customers prefer to play games on mobile devices while 62% prefer playing on PC."
      ],
      next: "P5"
    },
    {
      source: "Message",
      id: "P5",
      category: "Profiling",
      text: [
        "Please tell me your need so that it would enable me to guide you to precisely the machine that fits."
      ],
      options: [
        {
          text: "General home use",
          display: "General home use",
          value: "home use",
          attr: "typeOfMachine",
          next: "P5_1"
        },
        {
          text: "Graphics intensive tasks",
          display: "Graphics intensive tasks",
          value: "intensive tasks",
          attr: "typeOfMachine",
          next: "P5_2"
        },
        {
          text: "General office use",
          display: "General office use",
          value: "Office use",
          attr: "typeOfMachine",
          next: "P5_3"
        },
        {
          text: "Gaming",
          display: "For some serious gaming",
          value: "Gaming",
          attr: "typeOfMachine",
          next: "P5_4"
        }
      ]
    },
    {
      source: "Message",
      id: "P5_1",
      category: "Profiling",
      text: ["Being happy in general makes life so much easier. Tom Daley"],
      image: [
        {
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture2.jpg"
        }
      ],
      next: "R1"
    },
    {
      source: "Message",
      id: "P5_2",
      category: "Profiling",
      text: [
        "We need innovation in education and dedication to the task before us. Alan Autry"
      ],
      image: [
        {
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture2.jpg"
        }
      ],
      next: "R1"
    },
    {
      source: "Message",
      id: "P5_3",
      category: "Profiling",
      text: [
        "Great companies are built in the office, with hard work put in by a team. Emily Chang "
      ],
      image: [
        {
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture2.jpg"
        }
      ],
      next: "R1"
    },
    {
      source: "Message",
      id: "P5_4",
      category: "Profiling",
      text: [
        "Did you know? 76% of customers prefer to play games on mobile devices while 62% prefer playing on PC."
      ],
      image: [
        {
          url: "https://wpdev.eclerx.com:4502/chatbot/assets/Picture2.jpg"
        }
      ],
      next: "R1"
    },
    {
      source: "Message",
      id: "R1",
      category: "Recommendation",
      text: [
        "Presenting before you, the top 5 <b>BEASTS</b>!!! But we’ve even more."
      ],
      execute: {
        proc: "getRecommended",
        next: {
          true: "C1"
        }
      }
    },
    {
      source: "Message",
      id: "C1",
      category: "Profiling",
      text: ["Could I be of any more help to you?"],
      options: [
        {
          text: "Explore the rest",
          display: "Explore the rest",
          execute: {
            proc: "gotoProductPage",
            next: {
              true: "G3"
            }
          }
        },
        {
          text: "Find answers",
          display: "Find answers",
          execute: {
            proc: "initFAQ"
          }
        },
        {
          text: "Close Input",
          display: "Close Input",
          execute: {
            proc: "closeFAQ"
          }
        },
        {
          text: "Back to where we started",
          display: "Back to where we started",
          next: "G2"
        }
      ]
    },
    {
      source: "Message",
      id: "G3",
      category: "Profiling",
      text: ["Could I be of any more help to you?"],
      options: [
        {
          text: "Explore the rest",
          display: "Explore the rest",
          execute: {
            proc: "gotoProductPage",
            next: {
              true: "G3"
            }
          }
        },
        {
          text: "Back to where we started",
          display: "Back to where we started",
          next: "G2"
        }
      ]
    }
  ];

  userProfileData: any = {};

  didYouMeanList: any;

  private handleError<T>(operation = "operation", result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  constructor(private http: HttpClient) {}

  getData(id: String): Observable<any[]> {
    console.log("id is :", id);

    // FOR USE AFTER DATA CONNECTIVITY
    // return this.http.get<any[]>(apiUrl + id).pipe(
      return this.http.get<any[]>(apiUrl).pipe(
      map(data => {
        return data;
      })
    );
  }

  //Make config service
  // |-> URLs = {}; chatMessages : "url"
  // |-> start chat id = "G1"
  // Private temp[orary functio to parse this temporry variable and get required object

  getTempData(id: any) {
    for (let i = 0; i < this.b.length; i++) {
      if (id == this.b[i].id) {
        return this.b[i];
      }
    }
  }
  getCarouselData() {
    return this.carousel;
  }

  getAns(question: String): Observable<any[]> {
    console.log("question is :", question);
    let paramsObj:any = {
      isLearn: 0,
      rows: 5, //25,
      search: question, //"I am unable to copy and paste in autocad",
      sort: "score",
      start: 0
    };
    let params = new HttpParams(paramsObj);

    // FOR USE AFTER DATA CONNECTIVITY
    // return this.http.get<any[]>(faqUrl, {params}).pipe(
      return this.http.get<any[]>(apiUrl).pipe(
      map((data:any) => {
        console.log(data);
        this.didYouMeanList = data.searchResults;
        return data.searchResults;
      })
    );
  }
}
