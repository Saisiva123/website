import { DataManagerService } from "./data.svc";
import { ConfigServcie } from "./config.svc";
import { Injectable } from "@angular/core";
import { Observable, of, BehaviorSubject, Subject } from "rxjs";
import { UtilService } from "./../services/util.svc";
// import { EcCbWindow } from "../../chatbot/window/window.component";

@Injectable({
  providedIn: "root"
})
export class ExcuteService {
  // private dataManagerService: DataManagerService;
  // private configServcie: ConfigServcie;
  didYouMeanList: Subject<any> = new Subject();
  constructor(
    private dataManagerService: DataManagerService,
    private configServcie: ConfigServcie,
    private utilService: UtilService
  ) // private ecCbWindow: EcCbWindow
  {}

  gotoProductPage() {
    console.log(this.dataManagerService.userProfileData);
    // window.open("https://www.google.com", "_blank");
    // const getProductPageURL: String = params => {
    let getProductPageURL = params => {
      return [
        this.configServcie.URLs.shop,
        params.location,
        params.productType
      ].join("/");
    };
    // this.dataManagerService.userProfileData[opt.attr] = opt.value;
    let url: string = getProductPageURL(
      this.dataManagerService.userProfileData
    );

    window.open(url, "_blank");

    return "true";
  }
  getRecommended() {
    //TODO
    // this.Carousel = this.dataManagerService.getCarouselData();
    // this.carouselObj = new CarouselObj('UserResponse', this.Carousel);
    // this.Messsage.push(this.carouselObj);
    return "true";
  }
  initFAQ() {
    //Enable the text fields and send button
    //Turn On FAQ mode
    this.utilService.setInputActive(true);
    return "true";
  }
  closeFAQ() {
    this.utilService.setInputActive(false);
    return "true";
  }
  showDYM() {
    // let didYouMeanLimit:number=5;
    // let didYouMeanList:string = `I am sorry to know that. But did you mean any of these?<br/>`;
    // for (var i = 0; i < this.dataManagerService.didYouMeanList.length; ++i) {
    //   didYouMeanList += `<a href="#" onclick="">${this.dataManagerService.didYouMeanList[i]}`
    // }
    // this.ecCbWindow.onEmitOptionOnWindow();
    // this.ecCbWindow.Messsage.push({
    //   text: `I am sorry to know that. But did you mean any of these?`,
    //   didYouMeanList: this.dataManagerService.didYouMeanList
    // });

    this.didYouMeanList.next(this.dataManagerService.didYouMeanList);
    return true;
  }
}
