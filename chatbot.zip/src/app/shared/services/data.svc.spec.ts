import { TestBed } from '@angular/core/testing';

import { DataManagerService } from './data.svc';
import { HttpClientModule,HttpClient } from '@angular/common/http';

describe('DataManagerService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule],
    providers: [DataManagerService]
  }));

  it('should be created', () => {
    const service: DataManagerService = TestBed.get(DataManagerService);
    expect(service).toBeTruthy();
  });
});
