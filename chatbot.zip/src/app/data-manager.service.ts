import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import {
  HttpClient,
} from "@angular/common/http";
import { catchError, tap, map } from "rxjs/operators";

const apiUrl = "../assets/data/chat.json";

@Injectable({
  providedIn: "root"
})
export class DataManagerService {
  public data;
  private handleError<T>(operation = "operation", result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  constructor(private http: HttpClient) { }

  getData() {
    return this.http.get(apiUrl).pipe(
      tap(heroes => console.log("fetched products", heroes)),
      catchError(this.handleError("getProducts", []))
    );
  }
}
